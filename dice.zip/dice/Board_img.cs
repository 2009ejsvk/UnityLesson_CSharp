﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dice
{
    internal class Board_img
    {
        public int board_dice_num = 1;
        public void board_img_print()
        {
            if (board_dice_num == 1)
            {
                Console.WriteLine("      □□□□      ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("      □□□▣      ");
            }
            else if (board_dice_num == 2)
            {
                Console.WriteLine("      □□□□      ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("      □□▣□      ");
            }
            else if (board_dice_num == 3)
            {
                Console.WriteLine("      □□□□      ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("      □▣□□      "); 
            }
            else if (board_dice_num == 4)
            {
                Console.WriteLine("      □□□□      ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("      ▣□□□      ");
            }
            else if (board_dice_num == 5)
            {
                Console.WriteLine("      □□□□      ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("    ▣        ▩    ");
                Console.WriteLine("      □□□□      ");
            }
            else if (board_dice_num == 6)
            {
                Console.WriteLine("      □□□□      ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  ▣            □  ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("      □□□□      ");
            }
            else if (board_dice_num == 7)
            {
                Console.WriteLine("      □□□□      ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  ▣            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("      □□□□      ");
            }
            else if (board_dice_num == 8)
            {
                Console.WriteLine("      □□□□      ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  ▣            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("      □□□□      ");
            }
            else if (board_dice_num == 9)
            {
                Console.WriteLine("      □□□□      ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("  ▣            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("      □□□□      ");
            }
            else if (board_dice_num == 10)
            {
                Console.WriteLine("      □□□□      ");
                Console.WriteLine("    ▣        ▩    ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("      □□□□      ");
            }
            else if (board_dice_num == 11)
            {
                Console.WriteLine("      ▣□□□      ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("      □□□□      ");
            }
            else if (board_dice_num == 12)
            {
                Console.WriteLine("      □▣□□      ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("      □□□□      ");
            }
            else if (board_dice_num == 13)
            {
                Console.WriteLine("      □□▣□      ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("      □□□□      ");
            }
            else if (board_dice_num == 14)
            {
                Console.WriteLine("      □□□▣      ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("      □□□□      ");
            }
            else if (board_dice_num == 15)
            {
                Console.WriteLine("      □□□□      ");
                Console.WriteLine("    ▩        ▣    ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("      □□□□      ");
            }
            else if (board_dice_num == 16)
            {
                Console.WriteLine("      □□□□      ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("  □            ▣  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("      □□□□      ");
            }
            else if (board_dice_num == 17)
            {
                Console.WriteLine("      □□□□      ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            ▣  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("      □□□□      ");
            }
            else if (board_dice_num == 18)
            {
                Console.WriteLine("      □□□□      ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            ▣  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("      □□□□      ");
            }
            else if (board_dice_num == 19)
            {
                Console.WriteLine("      □□□□      ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            ▣  ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("      □□□□      ");
            }
            else if (board_dice_num == 20)
            {
                Console.WriteLine("      □□□□      ");
                Console.WriteLine("    ▩        ▩    ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("  □            □  ");
                Console.WriteLine("    ▩        ▣    ");
                Console.WriteLine("      □□□□      ");
            }
        }
    }
}
